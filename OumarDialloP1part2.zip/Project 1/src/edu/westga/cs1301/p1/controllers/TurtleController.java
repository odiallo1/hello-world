package edu.westga.cs1301.p1.controllers;

import edu.westga.cs1301.p1.model.Turtle;

/**
 * Uses Turtle objects to draw on the screen.
 * 
 * @author CS 1301
 * @version Fall 2020
 */
public class TurtleController {
	//TODO part 1 - add big turtle field
	private Turtle bigTurtle;
	//TODO part 2 - add small turtle field
	private Turtle smallTurtle;
	/**
	 * Creates and initializes a new TurtleController object.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 */
	public TurtleController() {
		//TODO part 1 - initialize big turtle field
		bigTurtle= new Turtle();
		//TODO part 2 - initialize small turtle field
		smallTurtle= new Turtle(20);
	}

	/**
	 * Draws a figure on the screen using turtle objects.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public void draw() {
		//TODO part 1 - draw house frame with big turtle
		this.moveBigTurtleToHouse();
		this.bigTurtleDrawHouseFrame();
		//TODO part 1 - draw roof with big turtle
		this.bigTurtleDrawRoof();
		//TODO part 2 - draw door with small turtle
		this.smallTurtleMoveToDoor();
		this.smallTurtleDrawDoor();
		//TODO part 2 - draw 2 windows with small turtle
		this.moveToLeftWindow();
		this.drawWindow();
		this.multipleSmallSteps(9);
		this.drawWindow();
	}

	private void moveToLeftWindow() {
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.multipleSmallSteps(7);
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.multipleSmallSteps(10);
		
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
	}

	private void drawWindow() {
		this.smallTurtle.lowerTail();
		
		this.multipleSmallSteps(3);
		
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.multipleSmallSteps(3);
		
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.multipleSmallSteps(3);
		
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.multipleSmallSteps(3);
		
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.smallTurtle.raiseTail();
	}

	private void smallTurtleMoveToDoor() {
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		
		this.multipleSmallSteps(25);
		this.smallTurtle.turnLeft30();
		this.smallTurtle.turnLeft30();
		this.smallTurtle.turnLeft30();
		this.multipleSmallSteps(20);
	}

	private void smallTurtleDrawDoor() {
		this.smallTurtle.lowerTail();
		this.smallTurtle.turnLeft30();
		this.smallTurtle.turnLeft30();
		this.smallTurtle.turnLeft30();
		this.multipleSmallSteps(5);
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.multipleSmallSteps(3);
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.smallTurtle.turnRight30();
		this.multipleSmallSteps(5);
		this.smallTurtle.raiseTail();
	}

	private void bigTurtleDrawRoof() {
		this.bigTurtle.turnLeft30();
		this.bigTurtle.turnLeft30();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		this.bigTurtle.raiseTail();
	}

	private void bigTurtleDrawHouseFrame() {
		this.bigTurtle.lowerTail();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
	}

	private void moveBigTurtleToHouse() {
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		this.bigTurtle.turnRight30();
		
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		
		this.bigTurtle.turnLeft30();
		this.bigTurtle.turnLeft30();
		this.bigTurtle.turnLeft30();
		
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();
	}
	
	private void multipleSmallSteps(int steps){
		for(int i=0; i < steps; i++) {
			this.smallTurtle.stepForward();
		}
	}
	
	private void printStats(Turtle stat) {
		int totalSteps= stat.getStepCount();
		
		System.out.println("took " + totalSteps + " steps.");
	}
	/** 
	 * Print summary statistics about the turtles.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public void print() {
		//TODO part 1 - print summary statistics about big turtle
		System.out.print("bigTurtle ");
		this.printStats(bigTurtle);
		//TODO part 2 - print summary statistics about small turtle
		System.out.print("smallTurtle ");
		this.printStats(smallTurtle);
	}

}