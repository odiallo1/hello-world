package edu.westga.cs1301.p1.view;

import java.lang.reflect.Field;

import acm.program.*;
import edu.westga.cs1301.p1.controllers.TurtleController;
import edu.westga.cs1301.p1.model.Turtle;

/**
 * The GUI for the application.
 * 
 * @author CS 1301
 * @version Fall 2020
 * 
 */
public class Gui extends GraphicsProgram {

	public static final int APPLICATION_WIDTH = 750;
	public static final int APPLICATION_HEIGHT = 750;
	private static final long serialVersionUID = 1L;

	private TurtleController controller;

	/**
	 * Constructs and initializes the GUI.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public Gui() {
		this.controller = new TurtleController();
	}

	/**
	 * Initializes the application.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public void init() {
		this.setSize(APPLICATION_WIDTH, APPLICATION_HEIGHT);
		
		this.setTitle("Project 1 - Fall 2020");

		this.addTurtlesToWindowUsingReflection();

	}

	private void addTurtlesToWindowUsingReflection() {
		Field[] fields = this.controller.getClass().getDeclaredFields();

		for (Field currField : fields) {
			try {
				currField.setAccessible(true);
				Turtle turtle = (Turtle) currField.get(this.controller);
				super.add(turtle);
				currField.setAccessible(false);
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Part of the execution cycle for the application.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public void run() {
		this.controller.draw();
		this.controller.print();
	}

}
