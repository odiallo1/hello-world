package edu.westga.cs1301.p1.model;

import acm.graphics.GTurtle;

/**
 * Turtle represents a graphical turtle that can move around on the screen,
 * turn, and raise or lower its tail. When its tail is lowered, it "scratches" a
 * line on the screen that shows the path it takes.
 * 
 * @author CS 1301
 * @version Fall 2020
 */
public class Turtle extends GTurtle {

	public static final double INITIAL_TURTLE_SPEED = 0.7;
	public static final int INITIAL_SIZE = 50;
	
	private int stepCount;
	
	//TODO part 3 - add a field to store the name of the Turtle

	/**
	 * Creates a new Turtle object of size 50 at location (25, 25).
	 * 
	 * @precondition none
	 * @postcondition isTailDown() == false AND 
	 * 				  getTurtleSize() == INITIAL_SIZE(50) AND 
	 * 				  getLocation() == (25, 25) AND
	 *                getSpeed() == INITIAL_TURTLE_SPEED(0.6)
	 * 
	 */
	public Turtle() { //TODO part 3 - add a parameter for the name of the turtle, and initialize the name field
		this.initialize();
	}

	/**
	 * Creates a new Turtle object at location (25, 25) with the specified size.
	 * 
	 * @precondition none
	 * @postcondition isTailDown() == false AND 
	 * 				  getTurtleSize() == size AND 
	 * 				  getLocation() == (25, 25) AND
	 *                getSpeed() == INITIAL_TURTLE_SPEED(0.6)
	 *                
	 * @param size the size of the Turtle
	 */
	public Turtle(int size) { //TODO part 3 - add a parameter for the name of the turtle, and initialize the name field
		this.initialize();
		this.setSize(size);
	}

	private void initialize() {
		this.setSize(Turtle.INITIAL_SIZE);
		this.setSpeed(Turtle.INITIAL_TURTLE_SPEED);
		this.setLocation(Turtle.INITIAL_SIZE / 2, Turtle.INITIAL_SIZE / 2);
		this.stepCount = 0;
	}

	/**
	 * Moves the turtle forward in its current direction by a distance equal to
	 * its own size. The turtle draws a line if its tail is down, but otherwise
	 * just moves.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public void stepForward() {
		this.forward();
		this.stepCount++;
	}

	/**
	 * Turns the turtle 30 degrees to its left.
	 *
	 * @precondition none
	 * @postcondition none
	 */
	public void turnLeft30() {
		this.left(30.0);
	}

	/**
	 * Turns the turtle 30 degrees to its right.
	 *
	 * @precondition none
	 * @postcondition none
	 */
	public void turnRight30() {
		this.right(30.0);
	}

	/**
	 * Drops the turtle's tail to the ground so it will draw a line when it
	 * moves.
	 * 
	 * @precondition none
	 * @postcondition isTailDown() == true
	 */
	public void lowerTail() {
		this.penDown();
	}

	/**
	 * Lifts the turtle's tail from the ground so it won't draw a line when it
	 * moves.
	 * 
	 * @precondition none
	 * @postcondition isTailDown() == false.
	 */
	public void raiseTail() {
		this.penUp();
	}
	
	/**
	 * Returns the number of steps the Turtle has take so far.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the number of steps the Turtle has take so far
	 */
	public int getStepCount() {
		return this.stepCount;
	}
	
	//TODO part 3 - add a getter for the name field
}
